This folder contains only csv files
